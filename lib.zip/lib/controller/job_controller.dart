import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get_storage/get_storage.dart';

import '../model/common_model.dart';
import '../model/job_listing_model.dart';
import '../model/responsemodel/JobListResponse.dart';
import '../utills/Utils.dart';
import '../utills/constant.dart';
import '../webservices/WebServicesHelper.dart';
import './pharmcy_profile_controller.dart';
import 'package:geocoding/geocoding.dart';
import 'dart:io';


class JobPostController extends GetxController {
  // ================= STORE =================
  int storeId = 0;
  String accessToken = '';
  String userId = '';

  late GetStorage store;
  late PharmacyProfileController pharmacyController;

  // ================= TEXT CONTROLLERS =================
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final jobTypeController = TextEditingController();

  final experienceMinController = TextEditingController();
  final experienceMaxController = TextEditingController();

  final salaryFromController = TextEditingController();
  final salaryToController = TextEditingController();

  final stateController = TextEditingController();
  final cityController = TextEditingController();
  final latitudeController = TextEditingController();
  final longitudeController = TextEditingController();
  final lastApplyDateController = TextEditingController();



  // ================= LOADING =================
  RxBool isLoading = false.obs;
  RxBool isLoadingMyJobs = false.obs;
  RxBool isFetchingLocation = false.obs;
  RxBool isLoadingStates = false.obs;
  RxBool isLoadingApplicants = false.obs;

  // ================= STATE / CITY =================
  RxList<CommonModel> stateList = <CommonModel>[].obs;
  RxList<CommonModel> cityList = <CommonModel>[].obs;

  Rx<CommonModel> selectedState = CommonModel().obs;
  Rx<CommonModel> selectedCity = CommonModel().obs;

  // ================= SKILLS =================
  RxList<String> skills = <String>[].obs;

  // ================= JOB LIST =================
  RxList<JobListingModel> myJobs = <JobListingModel>[].obs;
  RxList<dynamic> jobApplicants = <dynamic>[].obs;
  RxInt selectedJobId = 0.obs;

  // ================= JOB TYPE =================
  RxString selectedJobType = "".obs;

  final List<String> jobtypes = [
    "Full-Time",
    "Part-Time",
    "Contract",
    "Internship"
  ];

// Experience Type
// ================= CATEGORY =================
RxList<JobCategoryModel> categoryList = <JobCategoryModel>[].obs;
RxList<JobSubCategoryModel> subCategoryList = <JobSubCategoryModel>[].obs;

Rx<JobCategoryModel> selectedCategory = JobCategoryModel().obs;
Rx<JobSubCategoryModel> selectedSubCategory = JobSubCategoryModel().obs;

RxBool isLoadingCategory = false.obs;
RxBool isLoadingSubCategory = false.obs;

// ================= ADDITIONAL INFO =================
final contactNumberController = TextEditingController();
final emailController = TextEditingController();
final postedByNameController = TextEditingController();

// Gender
String selectedGender = "male";

final List<String> genderList = [
  "MALE",
  "FEMALE",
  "OTHER"
];

// Experience Type (Fresher / Experienced)
RxString selectedWorkType = "".obs;
final List<String> workTypeList = [
  "OFFICE",
  "REMOTE",
  "HYBRID"
];
// ================= IMAGE =================
RxBool isUploadingImage = false.obs;
RxList<Map<String, dynamic>> jobImageList = <Map<String, dynamic>>[].obs;RxString displayAddress = "".obs;

// Category Type (Dropdown Selection)
RxString selectedCategoryType = "".obs;

final List<String> categoryTypeList = [
  "CAREER",
  "BUSINESS",
  "DOMESTIC",
  "FRESHER",
];

// Salary Type
RxString selectedSalaryType = "ANNUAL".obs;

final List<String> salaryTypeList = [
  "ANNUAL (LPA)",
  "MONTHLY"
];
// ================= LIVE PREVIEW =================
RxString jobTitle = "".obs;
RxString jobDescription = "".obs;
  // ================= INIT =================
  @override
  void onInit() {
    super.onInit();

    store = GetStorage();
    final args = Get.arguments;

    storeId = args?['storeId'] ?? 0;
    accessToken = store.read(Constant.access_token) ?? '';
    userId = store.read(Constant.user_id)?.toString() ?? '';

    // ✅ SAFE CONTROLLER INIT (OLD GETX SUPPORT)
    if (Get.isRegistered<PharmacyProfileController>()) {
      pharmacyController = Get.find<PharmacyProfileController>();
    } else {
      pharmacyController = Get.put(PharmacyProfileController());
    }
    // 🔥 ADD THESE LISTENERS FOR PREVIEW
  titleController.addListener(() {
    jobTitle.value = titleController.text;
  });

  descriptionController.addListener(() {
    jobDescription.value = descriptionController.text;
  });

    // ✅ LOAD PROFILE FIRST
    pharmacyController.getPharmacyDetailsApi();

    loadStates();
    fetchCurrentLocation();
    getJobDetailApi();
    loadJobCategories("BUSINESS");
  }

  // ================= JOB TYPE =================
void selecteJobType(String type) {
  selectedJobType.value = type;
  jobTypeController.text = type;
}


  // ================= LOCATION =================
  Future<void> fetchCurrentLocation() async {
  try {
    isFetchingLocation.value = true;

    /// 1️⃣ Check if location service enabled
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      displayAddress.value = "Location service disabled";
      return;
    }

    /// 2️⃣ Check permission
    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.deniedForever ||
        permission == LocationPermission.denied) {
      displayAddress.value = "Location permission denied";
      return;
    }

    /// 3️⃣ Get position
    final position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    /// 4️⃣ Save lat/lng (for backend)
    latitudeController.text = position.latitude.toString();
    longitudeController.text = position.longitude.toString();

    /// 5️⃣ Convert to readable address (for UI only)
    await convertLatLngToAddress(
      position.latitude,
      position.longitude,
    );

  } catch (e) {
    displayAddress.value = "Failed to fetch location";
  } finally {
    isFetchingLocation.value = false;
  }
}

  // ================= STATE / CITY =================
  void onSelect(String type, CommonModel data) {
    if (type == 'state') {
      selectedState.value = data;
      stateController.text = data.name ?? "";
      selectedCity.value = CommonModel();
      cityController.clear();
      loadCities(data.id.toString());
    } else {
      selectedCity.value = data;
      cityController.text = data.name ?? "";
    }
  }

  Future<void> loadStates() async {
    try {
      isLoadingStates.value = true;
      final response = await WebServicesHelper().getStateList();
      if (response != null && response['status'] == 200) {
        stateList.assignAll(
          (response['data'] as List)
              .map((e) => CommonModel.fromJson(e))
              .toList(),
        );
      }
    } finally {
      isLoadingStates.value = false;
    }
  }

  Future<void> loadCities(String stateId) async {
    final response = await WebServicesHelper().getCityList(stateId);
    if (response != null && response['status'] == 200) {
      cityList.assignAll(
        (response['data'] as List)
            .map((e) => CommonModel.fromJson(e))
            .toList(),
      );
    }
  }
  void selectCategory(JobCategoryModel category) {
  selectedCategory.value = category;
  selectedSubCategory.value = JobSubCategoryModel();
  subCategoryList.clear();

  if (category.id != null) {
    loadJobSubCategories(category.id!);
  }
}

void selectSubCategory(JobSubCategoryModel subCategory) {
  selectedSubCategory.value = subCategory;
}

  // ================= SKILLS =================
  void addSkill(String skill) {
    final value = skill.trim();
    if (value.isNotEmpty && !skills.contains(value)) {
      skills.add(value);
    }
  }

  List<Map<String, dynamic>> buildSkillsPayload() {
    return skills.map((e) => {"skill": e}).toList();
  }

  // ================= POST JOB =================
  Future<void> postJobByStoreApi() async {
  final uid = int.tryParse(userId);
  if (uid == null) {
    Utils.showCustomTosstError("User not logged in");
    return;
  }

  // ================= BASIC VALIDATIONS =================
  if (selectedCategory.value.id == null) {
    Utils.showCustomTosstError("Please select valid category");
    return;
  }

  if (selectedSubCategory.value.id == null) {
    Utils.showCustomTosstError("Please select valid sub category");
    return;
  }

  if (selectedJobType.value.isEmpty) {
    Utils.showCustomTosstError("Please select job type");
    return;
  }

 

  if (selectedWorkType.value.isEmpty) {
    Utils.showCustomTosstError("Please select work type");
    return;
  }

  if (contactNumberController.text.trim().isEmpty) {
    Utils.showCustomTosstError("Please enter contact number");
    return;
  }

  if (postedByNameController.text.trim().isEmpty) {
    Utils.showCustomTosstError("Please enter posted by name");
    return;
  }

  if (titleController.text.trim().isEmpty) {
    Utils.showCustomTosstError("Please enter job title");
    return;
  }

  if (descriptionController.text.trim().isEmpty) {
    Utils.showCustomTosstError("Please enter job description");
    return;
  }

  // ================= STORE TYPE =================
  final storeType = pharmacyController.profileModel.value.storeType;

  if (storeType == null || storeType.isEmpty) {
    Utils.showCustomTosstError(
        "Store type not found. Please update profile.");
    return;
  }

  final storeTypeId = storeType[0].storeType?.id;
  if (storeTypeId == null) {
    Utils.showCustomTosstError("Invalid store type");
    return;
  }

 // default for Fresher

  int experienceMin =
    int.tryParse(experienceMinController.text.trim()) ?? 0;

int experienceMax =
    int.tryParse(experienceMaxController.text.trim()) ?? 0;

if (experienceMax < experienceMin) {
  Utils.showCustomTosstError(
      "Max experience must be greater than Min experience");
  return;
}
  // ================= BUILD PARAM =================
  final param = {
    "created_by": uid,
    "created_by_id": uid,
    "updated_by": uid,
    "updated_by_id": uid,

    "store_id": storeId,
    "store_type_id": storeTypeId,

    "job_category_id": selectedCategory.value.id,
    "job_sub_category_id": selectedSubCategory.value.id,

    "title": titleController.text.trim(),
    "description": descriptionController.text.trim(),

    "job_type": selectedJobType.value,
    "job_posted_by": postedByNameController.text.trim(),
    "contact_number": contactNumberController.text.trim(),
    "email": emailController.text.trim(),
    "gender": "MALE",
    "work_type": selectedWorkType.value,

    "experience_min": experienceMin,
    "experience_max": experienceMax,

    "salary_from":
        int.tryParse(salaryFromController.text.trim()) ?? 0,
    "salary_to":
        int.tryParse(salaryToController.text.trim()) ?? 0,

    "city_name": cityController.text.trim(),
    "state_name": stateController.text.trim(),
    "latitude": latitudeController.text,
    "longitude": longitudeController.text,

    "skills": buildSkillsPayload(),
    "last_apply_date": lastApplyDateController.text,

    "upload_photos": jobImageList,
  };





  // ================= API CALL =================
  isLoading.value = true;

  final response =
      await WebServicesHelper().postJobByStoreApi(param);

  isLoading.value = false;

  if (response != null && response['status'] == 201) {
    Get.snackbar(
  "Success",
  "Your job has been published successfully!",
  snackPosition: SnackPosition.BOTTOM,
  backgroundColor: Colors.green.shade600,
  colorText: Colors.white,
  borderRadius: 12,
  margin: const EdgeInsets.all(12),
  duration: const Duration(seconds: 3),
  icon: const Icon(Icons.check_circle, color: Colors.white),
);
     clearForm(); 
     Get.back();
    getJobDetailApi();
  } else {
    Utils.showCustomTosstError(response?['message'] ?? "Failed");
  }
}

  // ================= GET JOBS =================
  Future<void> getJobDetailApi() async {
  try {
    isLoadingMyJobs.value = true;

    final response = await WebServicesHelper().getJobyStoreApi({
      "store_id": storeId,
      "accessToken": accessToken,
    });

    if (response != null) {
      final model = JobListResponse.fromJson(response);

      // 🔥 IMPORTANT FIX
      myJobs.clear();
      myJobs.value = model.jobListing ?? [];
      myJobs.refresh();
    }
  } finally {
    isLoadingMyJobs.value = false;
  }
}
  // ================= GET APPLICANTS =================
  Future<void> getApplicantsForJob(int jobId) async {
    try {
      isLoadingApplicants.value = true;
      selectedJobId.value = jobId;

      final response =
          await WebServicesHelper().getListAppliedJobByJobId({
        "job_id": jobId.toString(),
        "page": "1",
        "size": "50",
        "accessToken": accessToken,
      });

      jobApplicants.clear();
      if (response != null && response['status'] == 200) {
        jobApplicants.assignAll(response['data'] ?? []);
      }
    } finally {
      isLoadingApplicants.value = false;
    }
  }

 Future<void> loadJobCategories(String categoryType) async {
  try {
    isLoadingCategory.value = true;

    selectedCategoryType.value = categoryType;

    final response =
        await WebServicesHelper().getstoreJobcategory({
      "category_type": categoryType,
    });

    if (response != null && response['status'] == 200) {

      categoryList.assignAll(
        (response['data'] as List)
            .map((e) => JobCategoryModel.fromJson(e))
            .toList(),
      );

      // Reset selection when type changes
      selectedCategory.value = JobCategoryModel();
      selectedSubCategory.value = JobSubCategoryModel();
      subCategoryList.clear();
    }

  } catch (e) {
    Utils.showCustomTosstError("Failed to load categories");
  } finally {
    isLoadingCategory.value = false;
  }
}

Future<void> loadJobSubCategories(int categoryId) async {
  try {
    isLoadingSubCategory.value = true;

    final response =
        await WebServicesHelper().getJobSubCategory(categoryId);

    if (response != null && response['status'] == 200) {
      subCategoryList.assignAll(
        (response['data'] as List)
            .map((e) => JobSubCategoryModel.fromJson(e))
            .toList(),
      );
    }
  } finally {
    isLoadingSubCategory.value = false;
  }
}

Future<void> uploadJobImageFromFile(File imageFile) async {
  try {
    isUploadingImage.value = true;

    final uploadRes =
        await WebServicesHelper().fileUpload("image", imageFile);

    if (uploadRes == null || uploadRes['status'] != 200) {
      Utils.showCustomTosstError("Image upload failed");
      return;
    }

    final imageForApi = {
      "name": uploadRes['data']['name'],
      "path": uploadRes['data']['path'],
      "size": uploadRes['data']['size'] ?? await imageFile.length(),
    };

    jobImageList.clear();
    jobImageList.add(imageForApi);

    Utils().customPrint("JOB IMAGE LIST => $jobImageList");

  } catch (e) {
    Utils().customPrint("Job Image Upload Error => $e");
    Utils.showCustomTosstError("Image upload error");
  } finally {
    isUploadingImage.value = false;
  }
}
Future<void> convertLatLngToAddress(
    double latitude, double longitude) async {
  try {
    List<Placemark> placemarks =
        await placemarkFromCoordinates(latitude, longitude);

    if (placemarks.isNotEmpty) {
      final place = placemarks.first;

      displayAddress.value =
          "${place.locality ?? ""}, "
          "${place.subAdministrativeArea ?? ""}, "
          "${place.administrativeArea ?? ""}";
          cityController.text = place.locality ?? "";
stateController.text = place.administrativeArea ?? "";
    }
  } catch (e) {
    displayAddress.value = "Location found";
  }
}
  @override
  void onClose() {
    titleController.dispose();
    descriptionController.dispose();
    jobTypeController.dispose();
    experienceMinController.dispose();
    experienceMaxController.dispose();
    salaryFromController.dispose();
    salaryToController.dispose();
    stateController.dispose();
    cityController.dispose();
    latitudeController.dispose();
    longitudeController.dispose();
    lastApplyDateController.dispose();
    contactNumberController.dispose();
emailController.dispose();
postedByNameController.dispose();
    super.onClose();
  }



  void clearForm() {
  // Text fields
  titleController.clear();
  descriptionController.clear();
  jobTitle.value = "";
jobDescription.value = "";
  jobTypeController.clear();
  experienceMinController.clear();
  experienceMaxController.clear();
  salaryFromController.clear();
  salaryToController.clear();
  stateController.clear();
  cityController.clear();
  latitudeController.clear();
  longitudeController.clear();
  lastApplyDateController.clear();
  contactNumberController.clear();
  emailController.clear();
  postedByNameController.clear();

  // Dropdown selections
  selectedJobType.value = "";
  selectedGender = "";
  selectedWorkType.value = "";
  selectedCategory.value = JobCategoryModel();
  selectedSubCategory.value = JobSubCategoryModel();
  selectedCategoryType.value = "";

  // Lists
  skills.clear();
  jobImageList.clear();
  subCategoryList.clear();

  // Location display
  displayAddress.value = "";
}
}
